package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.vo.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class DefaultController {

	// @RequestMapping("/"): GET, POST, DELETE, PUT, UPDATE
	@GetMapping("/")
	public ModelAndView index(HttpServletRequest request) {
		
		HttpSession session = request.getSession();
		MemberVO memberInfo = (MemberVO)session.getAttribute("userInfo");
		
//		if (memberInfo != null) {
//			log.info(memberInfo.toString());
//		} else {
//			log.info("세션 정보 없음");
//		}
		
		// ModelAndView: 데이터도 넣고 리턴해야될 html도 있을 때 사용
		ModelAndView mav = new ModelAndView();
		mav.addObject("memberInfo", memberInfo);
		// setViewName: jsp파일을 리턴해주는 용도
		mav.setViewName("common/index"); // 원래는 index.jsp
		// jsp 파일에서 사용할 데이터 오브젝트
		mav.addObject("title", "인덱스 페이지"); // addObject(jsp 파일에 넘길때 데이터의 키 값, 키 값의 value)
		
//		List<MemberVO> list = new ArrayList<>();
		
//		for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i).toString());
//		}
		// 위와 같음
//		for (MemberVO vo : list) {
//			System.out.println(vo.toString());
//		}
		
//		mav.addObject("memberList", list);
		
		return mav;
	}
}
