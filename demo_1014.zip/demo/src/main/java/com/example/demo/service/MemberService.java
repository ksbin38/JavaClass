package com.example.demo.service;

import java.util.List;

import com.example.demo.vo.MemberVO;

public interface MemberService {
	
	public List<MemberVO> selectList(MemberVO memberVO);
//		MemberVO memberVO = MemberVO.builder()
//			.userID(userID)
//			.password(password)
//			.build();
//		MemberVO memberVO2 = new MemberVO();
//		memberVO2.setUserID(userID);
//		memberVO2.setPassword(password);
//		return mapper.selectList(memberVO);
//	}
//	연산은 무조건 Service 클래스에서만
	
	MemberVO selectMember(Long idx);
	
	void deleteMember(Long idx);
	
	void updateMember(MemberVO memberVO);
	
	void insertMember(MemberVO memberVO);
	
}
