package com.example.demo.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.payload.request.JoinRequest;
import com.example.demo.service.MemberService;
import com.example.demo.vo.MemberVO;

//public class MemberService {
//	private final MemberMapper mapper;
//
//	public MemberService() {
//		this.mapper = new MemberMapper();
//	}
//}

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberMapper mapper;
	
	@Override
	public MemberVO selectOne(MemberVO e) {
		return mapper.selectOne(e);
	}
	
	public MemberVO selectOne(String userID, String password) {
		MemberVO vo = new MemberVO();
		vo.setUserID(userID);
		vo.setPassword(password);
		return mapper.selectOne(vo);
	}
	
	@Override
	public List<MemberVO> selectList(MemberVO memberVO) {
//		MemberVO memberVO = new MemberVO(); // or MemberVO memberVO = MemberVO.builder().userID(userID).password(password).build();
//		memberVO.setUserID(userID);
//		memberVO.setPassword(password);
		return mapper.selectList(memberVO);
	}

	@Override
	public MemberVO selectMember(Long idx) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMember(Long idx) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMember(MemberVO memberVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertMember(MemberVO memberVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(MemberVO memberVO) {
		// TODO Auto-generated method stub
		mapper.insert(memberVO);
	}

	@Override
	public void update(MemberVO memberVO) {
		// TODO Auto-generated method stub
		mapper.update(memberVO);
	}

	@Override
	public void delete(MemberVO memberVO) {
		// TODO Auto-generated method stub
		mapper.delete(memberVO);
	}
	
	public void memberDrop(Long idx) {
		mapper.memberDrop(idx);
	}
	
	public HashMap<String, Object> checkUserID(String userID) {
		int cnt = mapper.checkUserID(userID);
		// 리턴해야하는 객체가 단순한 숫자 연산의 결과타입이면 번거롭게 VO를 생성하지 말고 hashMap을 쓰면 편리하다
		HashMap<String, Object> map = new HashMap<>();
		map.put("isExist", cnt == 0? false: true);
		return map;
	}
	
	public HashMap<String, Object> checkEmail(String email) {
		int cnt = mapper.checkEmail(email);
		// 리턴해야하는 객체가 단순한 숫자 연산의 결과타입이면 번거롭게 VO를 생성하지 말고 hashMap을 쓰면 편리하다
		HashMap<String, Object> map = new HashMap<>();
		map.put("isExist", cnt == 0? false: true);
		return map;
	}
	
	public HashMap<String, Object> memberJoin(JoinRequest joinRequest) {
		// 리턴(받는것 포함)할 객체가 특정하기 어려운 경우 hashmap을 사용한다
		HashMap<String, Object> map = new HashMap<>();
		
		// 1. 아이디 중복 체크
		HashMap<String, Object> idMap = this.checkUserID(joinRequest.getUserID());
		boolean idExist = (boolean)idMap.get("isExist");
		
		if (idExist) {
			map.put("result", false);
			map.put("message", "아이디가 사용중입니다.");
			return map;
		}
		// 2. 이메일 중복 체크
		HashMap<String, Object> emailMap = this.checkEmail(joinRequest.getEmail());
		boolean emailExist = (boolean)emailMap.get("isExist");
		
		if (emailExist) {
			map.put("result", false);
			map.put("message", "이메일이 사용중입니다.");
			return map;
		}
		// 3. 비밀번호 확인(비번 2개가 동일한지, 비번 길이 4자 이상)
		String pw1 = joinRequest.getPassword();
		String pw2 = joinRequest.getPassword2();
		if (!pw1.equals(pw2)) {
			map.put("result", false);
			map.put("message", "비밀번호가 일치하지 않습니다.");
			return map;
		}
		if (pw1.length() < 4 || pw2.length() < 4) {
			map.put("result", false);
			map.put("message", "비밀번호를 4가 이상 입력하세요.");
			return map;
		}
		// 4. 사용자 이름 있는지 체크(4자 이상)
		String username = joinRequest.getUsername();
		
		MemberVO memberVO = MemberVO.builder()
				.email(joinRequest.getEmail())
				.userID(joinRequest.getUserID())
				.password(pw1)
				.username(username)
				.build();
		
		this.insert(memberVO);
		
		map.put("result", true);
		map.put("message", "회원가입 완료");
		// 가입 성공 여부 true, false
		// 메시지 "성공", "실패", "무언가 사유로 인한 실패"
		return map;
	}
	
	public HashMap<String, Object> findID(String email) {
		HashMap<String, Object> map = new HashMap<>();
		String userID = mapper.findID(email);
		
		map.put("result", userID == null ? false: true);
		map.put("message", userID == null ? "찾으시는 아이디가 없습니다." : "찾으시는 아이디는 " + userID + "입니다.");
		return map;
	}
	
}
