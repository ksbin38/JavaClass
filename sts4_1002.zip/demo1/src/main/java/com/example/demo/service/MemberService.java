package com.example.demo.service;

import java.util.List;
import com.example.demo.vo.MemberVO;

public interface MemberService {

	public List<MemberVO> selectList(MemberVO memberVO);
	
	MemberVO selectMember(Long idx);
	
	void deleteMember(Long idx);
	
	void updateMember(MemberVO memberVO);
	
	void insertMember(MemberVO memberVO);

	MemberVO selectOne(MemberVO e);
	
	void insert(MemberVO e);
	
	void update(MemberVO e);
	
	void delete(MemberVO e);
}
