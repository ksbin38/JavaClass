package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.demo.service.impl.BookService;
import com.example.demo.vo.Book;

import lombok.RequiredArgsConstructor;

@Controller
@RequiredArgsConstructor
@RequestMapping("/book")
public class BookController {

	@Autowired // 또는 private final
	private BookService service;
	
	@GetMapping("/selectAllList")
	// @ResponseBody 추가(위 어노테이션이 @Controller일 경우)
	public List<Book> selectAllList() {
		return service.selectAllList();
	}

}