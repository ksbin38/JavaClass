package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.BookMapper;
import com.example.demo.sevice.CrudService;
import com.example.demo.vo.Book;

@Service
public class BookService implements CrudService<Book> {

	@Autowired
	private BookMapper mapper;
	
	@Override
	public List<Book> selectAllList() {
		return mapper.selectList();
	}

}
