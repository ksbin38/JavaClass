package com.example.demo.sevice;

import java.util.List;

public interface CrudService<E> {
	
	List<E> selectAllList();

}
