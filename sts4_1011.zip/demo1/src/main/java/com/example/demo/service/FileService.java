package com.example.demo.service;

import org.springframework.stereotype.Service;

import com.example.demo.mapper.FileMasterMapper;
import com.example.demo.vo.FileMasterVO;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@AllArgsConstructor
public class FileService {

	private FileMasterMapper fileMasterMapper;
	
	public Long insertFileMaster(FileMasterVO fileMasterVO) {
		fileMasterMapper.insertFileMaster(fileMasterVO);
		return fileMasterVO.getFileMstID();
	}
}
