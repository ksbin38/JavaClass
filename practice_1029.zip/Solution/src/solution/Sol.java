package solution;

class Solution {
	public int solution(int[] array) {
        int answer = 0;
        int countA = 0; // 최빈값이 나온 횟수
        int x = array[0]; // 최빈값 저장을 위한 변수
        int countB = 0; // 최빈값과 비교하기 위한 다른 수가 나온 횟수
        int y = 0; // 최빈값과 비교하기 위한 다른 수 저장을 위한 변수
        for (int i = 0; i < array.length; i++) {
        	y = array[i];
            countB = 0;
            if (i == array.length - 1) {
                for (int j = 0; j < array.length; j++) {
                    if (y == array[j]) countB += 1;
                }
                if (x != y && countA == countB) { // 최빈값과 다른수가 있고 나타난 횟수가 동일할 때 -1
                    x = -1;
                }
            } else {
                for (int j = 0; j < array.length; j++) {
                    if (y == array[j]) countB += 1;
                }
                if (countA < countB) {
                    x = y;
                    countA = countB;
                } else if (x != y && countA == countB) {
                	x = -1;
                } else {
                	answer = x;
                }
            }
        }
        answer = x;
        return answer;
    }
}

public class Sol {
	
	public static void main(String[] args) {
		
		int[] arr = {1, 1, 2, 2, 3, 3, 3, 4};
		Solution sol = new Solution();
		
		int n = sol.solution(arr);
		
		System.out.println(n);
	}

}
