package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.MemberVO;

@Repository
public class MemberMapper {
	
	@Autowired
	private SqlSession session;

//	public MemberMapper(SqlSession session) {
//		this.session = session;
//	}
	
	public List<MemberVO> selectList(MemberVO memberVO) {
		return session.selectList("member.selectList", memberVO);
	}
	
	public MemberVO selectOne(MemberVO memberVO) {
		return session.selectOne("member.selectOne", memberVO);
	}
	
	public void insert(MemberVO memberVO) {
		session.insert("member.insert", memberVO);
	}
	
	public void update(MemberVO memberVO) {
		session.update("member.update", memberVO);
	}
	
	public void delete(MemberVO memberVO) {
		session.insert("member.delete", memberVO);
	}
	
	public void memberDrop(Long idx) {
		session.update("member.memberDrop", idx);
	}
}
