package com.example.demo.commonController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.service.impl.MemberServiceImpl;
import com.example.demo.vo.MemberVO;

import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/member")
@Slf4j
public class CommonController {
	
	@Autowired
	private MemberServiceImpl memberService;

	
	// 로그인 페이지 - 추후 구현
	@GetMapping("/login")
	public void login() {}
	
	@PostMapping("/loginProc")
	public void loginProc(
			@ModelAttribute MemberVO memberVO
//			@RequestParam(value = "userID", required = true, defaultValue = "") String userID,
//			@RequestParam(value = "password", required = true, defaultValue = "") String password
			) {
//		log.info("아이디: " + userID);
//		log.info("비밀번호 : " + password);
//		memberService.selectOne(userID, password);
		memberService.selectOne(memberVO);
	}
	
	@PostMapping("/joinProc")
	public void joinProc(@ModelAttribute MemberVO memberVO) {
		memberService.insert(memberVO);
	}
	
	@PostMapping("/updateProc")
	public void updateProc(@ModelAttribute MemberVO memberVO) {
		memberService.update(memberVO);
	}
	
	@PostMapping("/deleteProc")
	public void deleteProc(@ModelAttribute MemberVO memberVO) {
		memberService.delete(memberVO);
	}
	
	@GetMapping("/memberDrop")
	public void memberDrop(
			@RequestParam(value = "idx", required = true, defaultValue = "0") Long idx
			) {
		memberService.memberDrop(idx);
	}
}
