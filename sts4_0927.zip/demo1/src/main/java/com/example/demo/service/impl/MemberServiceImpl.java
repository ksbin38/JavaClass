package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.service.MemberService;
import com.example.demo.vo.MemberVO;

//public class MemberService {
//	private final MemberMapper mapper;
//
//	public MemberService() {
//		this.mapper = new MemberMapper();
//	}
//}

@Service
public class MemberServiceImpl implements MemberService {
	
	@Autowired
	private MemberMapper mapper;
	
	@Override
	public MemberVO selectOne(MemberVO e) {
		return mapper.selectOne(e);
	}
	
	public MemberVO selectOne(String userID, String password) {
		MemberVO vo = new MemberVO();
		vo.setUserID(userID);
		vo.setPassword(password);
		return mapper.selectOne(vo);
	}
	
	@Override
	public List<MemberVO> selectList(MemberVO memberVO) {
//		MemberVO memberVO = new MemberVO(); // or MemberVO memberVO = MemberVO.builder().userID(userID).password(password).build();
//		memberVO.setUserID(userID);
//		memberVO.setPassword(password);
		return mapper.selectList(memberVO);
	}

	@Override
	public MemberVO selectMember(Long idx) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMember(Long idx) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateMember(MemberVO memberVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insertMember(MemberVO memberVO) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void insert(MemberVO memberVO) {
		// TODO Auto-generated method stub
		mapper.insert(memberVO);
	}

	@Override
	public void update(MemberVO memberVO) {
		// TODO Auto-generated method stub
		mapper.update(memberVO);
	}

	@Override
	public void delete(MemberVO memberVO) {
		// TODO Auto-generated method stub
		mapper.delete(memberVO);
	}
	
	public void memberDrop(Long idx) {
		mapper.memberDrop(idx);
	}
	
}
