package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.vo.MemberVO;

@Controller
public class DefaultController {

	// @RequestMapping("/"): GET, POST, DELETE, PUT, UPDATE
	@GetMapping("/")
	// @PostMapping("/") 이런식으로 적으면 됨
	public ModelAndView index() {
		ModelAndView mav = new ModelAndView();
		// jsp 파일 지정
		mav.setViewName("index"); // index.jsp가 맞지만 index까지만 입력해도 가능
		// jsp 파일에서 사용할 데이터 오브젝트
		mav.addObject("title", "인덱스 페이지");
		
		List<MemberVO> list = new ArrayList<>();
		
		MemberVO m1 = new MemberVO();
		m1.setIdx(1L);
		m1.setIsAdmin(1);
		m1.setUserID("id1");
		m1.setPassword("123");
		m1.setUsername("이름");
		m1.setEmail("mail@mail.com");
		
		list.add(m1);
		
		MemberVO m2 = MemberVO.builder()
				.idx(2L)
				.isAdmin(0)
				.userID("id2")
				.password("456")
				.username("홍길동")
				.email("www@mail.com")
				.build();
		
		list.add(m2);
		
		MemberVO m3 = MemberVO.builder()
				.idx(3L)
				.isAdmin(0)
				.userID("id3")
				.password("789")
				.username("김철수")
				.email("kcs@mail.com")
				.build();
		
		list.add(m3);
		
		mav.addObject("memberList", list);
		
		for (int i = 0; i < list.size(); i++) {
			System.out.println(list.get(i).toString());
		}
		// 또는
		/*
		for (MemberVO vo : list) {
			System.out.println(vo.toString());
		}
		*/
		
		return mav;
	}
}
