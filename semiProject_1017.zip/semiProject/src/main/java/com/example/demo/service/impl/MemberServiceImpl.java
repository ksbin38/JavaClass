package com.example.demo.service.impl;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.payload.request.ChangePwRequest;
import com.example.demo.payload.request.JoinRequest;
import com.example.demo.service.CrudService;
import com.example.demo.util.StringUtil;
import com.example.demo.vo.MemberVO;

@Service
public class MemberServiceImpl implements CrudService<MemberVO> {

	@Autowired
	private MemberMapper mapper;
	
	@Override
	public List<MemberVO> selectList(MemberVO e) {
		return mapper.selectList(e);
	}

	@Override
	public MemberVO selectOne(MemberVO e) {
		return mapper.selectOne(e);
	}

	@Override
	public void insert(MemberVO e) {
		mapper.insert(e);
	}
	
	public HashMap<String, Object> checkUserID(String userID) {
		int cnt = mapper.checkUserID(userID);
		HashMap<String, Object> map = new HashMap<>();
		map.put("isExist", cnt == 0? false: true);
		return map;
	}
	
	public HashMap<String, Object> checkEmail(String email) {
		int cnt = mapper.checkEmail(email);
		HashMap<String, Object> map = new HashMap<>();
		map.put("isExist", cnt == 0? false: true);
		return map;
	}
	
	public HashMap<String, Object> memberJoin(JoinRequest joinRequest) {
		HashMap<String, Object> map = new HashMap<>();
		
		// 1. 아이디 중복 체크
		HashMap<String, Object> idMap = this.checkUserID(joinRequest.getUserID());
		boolean idExist = (boolean)idMap.get("isExist");
		
		if (idExist) {
			map.put("result", false);
			map.put("message", "아이디가 사용중입니다.");
			return map;
		}
		// 2. 이메일 중복 체크
		HashMap<String, Object> emailMap = this.checkEmail(joinRequest.getEmail());
		boolean emailExist = (boolean)emailMap.get("isExist");
		
		if (emailExist) {
			map.put("result", false);
			map.put("message", "이메일이 사용중입니다.");
			return map;
		}
		// 3. 비밀번호
		String pw = joinRequest.getPassword();
		// 4. 사용자 이름
		String username = joinRequest.getUsername();
		
		MemberVO memberVO = MemberVO.builder()
				.email(joinRequest.getEmail())
				.userID(joinRequest.getUserID())
				.password(pw)
				.username(username)
				.build();
		
		this.insert(memberVO);
		
		map.put("result", true);
		map.put("message", "회원가입 완료");
		
		return map;
	}
	
	public HashMap<String, Object> findID(String email) {
		HashMap<String, Object> map = new HashMap<>();
		String userID = mapper.findID(email);
		
		map.put("result", userID == null ? false : true);
		map.put("message", userID == null ? "찾으시는 아이디가 없습니다." : "찾으시는 아이디는 " + userID + "입니다.");
		return map;
	}
	
	public Object changePW(ChangePwRequest changePwRequest) {
		// 이메일, 아이디로 해당 row 존재 여부 확인 (row가 있으면 idx값이 리턴된다.)
		MemberVO memberVO = MemberVO.builder()
				.email(changePwRequest.getEmail())
				.userID(changePwRequest.getUserID())
				.build();
		Long idx = mapper.findPW(memberVO);
		
		HashMap<String, Object> map = new HashMap<>();
		
		// row가 없으면 계정 못찾는 메시지 리턴
		if (idx == null) {
			map.put("result", false);
			map.put("message", "계정을 찾을 수 없습니다.");
			return map;
		}
		
		// 계정이 있으면 랜덤하게 문자열을 생성해서 idx값에 해당하는 비밀번호 변경
		String randomPw = StringUtil.generateRandomString(6);
		
		// 기존에 memberVO가 있기때문에 별도로 생성 하지 않고 기존 변수명 활용
		memberVO = MemberVO.builder()
				.password(randomPw)
				.idx(idx).build();
		mapper.updatePW(memberVO);
		
		// 완료 메시지에 비밀번호를 넣어서 리턴
		map.put("result", true);
		map.put("message", "임시 비밀번호는 " + randomPw + "입니다.");
		
		return map;
	}

}
