package com.example.demo.commonController;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.payload.request.JoinRequest;
import com.example.demo.service.impl.MemberServiceImpl;
import com.example.demo.util.StringUtil;
import com.example.demo.vo.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequestMapping("/member")
@Slf4j
public class CommonController {
	
	@Autowired
	private MemberServiceImpl memberService;
	
	// 로그인 페이지 - 추후 구현
	@RequestMapping("/login") // requestMapping을 get/post 다 된다
	public ModelAndView login(
			@RequestParam(value = "userID", required = false, defaultValue = "") String userID,
			@RequestParam(value = "password", required = false, defaultValue = "") String password
			) {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("common/login");
		mav.addObject("title", "로그인");
		mav.addObject("userID", userID);
		mav.addObject("password", password);
		return mav;
	}
	
	@PostMapping("/loginProc")
	public ModelAndView loginProc(
			@ModelAttribute MemberVO memberVO,
			HttpServletRequest request
			) {
		
		ModelAndView mav = new ModelAndView();
		MemberVO result = memberService.selectOne(memberVO);
		if (result != null) {
			// 세션 부여
			log.info("로그인 성공");
			HttpSession session = request.getSession();
			session.setAttribute("userInfo", result);
			mav.setViewName("redirect:/");
		} else {
			// 로그인 실패
			log.info("로그인 실패");
			mav.setViewName("forward:/member/login");
		}
		return mav;
	}
	
	@GetMapping("/logout")
	public String logout(HttpServletRequest request) {
		HttpSession session = request.getSession();
		// 세션 삭제
		session.invalidate();
		return "redirect:/";
	}
	
	/**
	 * 회원가입 양식
	 * @return
	 */
	@GetMapping("/join")
	public ModelAndView join() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("member/join");
		return mav;
	}
	
	/**
	 * 회원가입 처리
	 * @param memberVO
	 */
	@PostMapping("/joinProc")
	public void joinProc(@ModelAttribute MemberVO memberVO) {
		memberService.insert(memberVO);
	}
	/**
	 * 회원가입 비동기 처리
	 * @param joinRequest
	 * @RequestBody 어노테이션이 있어야 post형식의 데이터를 받을 수 있다
	 * @return
	 */
	@PostMapping("/joinProc2")
	@ResponseBody
	public ResponseEntity<?> joinProc2(@RequestBody JoinRequest joinRequest) {
		return ResponseEntity.ok(memberService.memberJoin(joinRequest));
	}
	
	/**
	 * 비동기 통신 아이디 중복 확인
	 * @return
	 */
	@GetMapping("/checkUserID/{userID}")
	@ResponseBody
	public ResponseEntity<?> checkUserID(
			@PathVariable String userID
			) {
		HashMap<String, Object> result = memberService.checkUserID(userID);
		
		return ResponseEntity.ok(result);
	}
	
	/**
	 * 비동기 통신 이메일 중복 확인
	 * @param email
	 * @return
	 */
	@GetMapping("/checkEmail/{email}")
	@ResponseBody
	public ResponseEntity<?> checkEmail(
			@PathVariable String email
			) {
		HashMap<String, Object> result = memberService.checkEmail(email);
		return ResponseEntity.ok(result);
	}
	
	@GetMapping("/findID")
	public String findID() {
		return "common/findID";
	}
	
	/**
	 * 이메일로 아이디 찾기
	 * @param email
	 * @return
	 */
	@GetMapping("/findID/{email}")
	@ResponseBody
	public ResponseEntity<?> findIDByEmail(@PathVariable String email) {
		return ResponseEntity.ok(memberService.findID(email));
	}
	
	@GetMapping("/findPW")
	public String findPW() {
		return "common/findPW";
	}
	
	@PostMapping("/test")
	@ResponseBody
	public ResponseEntity<?> test(
			@RequestBody HashMap<String, Object> map) {
		
		log.info(map.toString());
		
		StringUtil.printMap("test", map);
		
		return ResponseEntity.ok("sdfsdfsdffds");
	}
	
}
