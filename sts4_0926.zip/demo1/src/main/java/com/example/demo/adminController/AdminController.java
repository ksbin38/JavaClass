package com.example.demo.adminController;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.service.impl.MemberService;
import com.example.demo.vo.MemberVO;

@Controller
@RequestMapping("/projectBakery")
public class AdminController {
	
	private final MemberService memberService;
	
	public AdminController(MemberService memberService) {
		this.memberService = memberService;
	}

	@GetMapping("/login")
	public ModelAndView login() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("projectBakery/login");
		return mav;
	}
	
	@GetMapping("/memberList")
	public ModelAndView memberList(@RequestParam("userID") String userID) {
		List<MemberVO> list = memberService.selectList(userID);
		// for (MemberVO vo : list) {
			// System.out.println(vo.toString());
		// }
		ModelAndView mav = new ModelAndView();
		mav.setViewName("admin/memberList");
		mav.addObject("title", list);
		mav.addObject("list", list);
		return mav;
	}
}
