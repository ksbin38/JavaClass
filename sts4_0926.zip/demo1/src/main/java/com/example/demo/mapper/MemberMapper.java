package com.example.demo.mapper;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.demo.vo.MemberVO;

@Repository
public class MemberMapper {
	private final SqlSession session;

	public MemberMapper(SqlSession session) {
		this.session = session;
	}
	
	public List<MemberVO> selectList(String userID) {
		return session.selectList("member.selectList", userID);
	}
}
