package com.example.demo.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.vo.MemberVO;

@Service
public class MemberService {
	private final MemberMapper mapper;

	public MemberService(MemberMapper mapper) {
		this.mapper = mapper;
	}
	
	public List<MemberVO> selectList(String userID) {
		return mapper.selectList(userID);
	}
	
}
