package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.service.CrudService;
import com.example.demo.service.MemberService;
import com.example.demo.vo.MemberVO;

@Service
public class MemberServiceImpl implements CrudService<MemberVO> {

	@Autowired
	private MemberMapper mapper;

//	public MemberService(MemberMapper mapper) {
//		this.mapper = mapper;
//	} // Autowired를 사용하면 이 내용은 필요없음
	
	@Override
	public List<MemberVO> selectList(MemberVO e) {
		return mapper.selectList(e);
	}

	@Override
	public MemberVO selectOne(MemberVO e) {
		return mapper.selectOne(e);
	}
	
	public MemberVO selectOne(String userID, String password) {
		MemberVO vo = new MemberVO();
		vo.setUserID(userID);
		vo.setPassword(password);
		return mapper.selectOne(vo);
	}

	@Override
	public void insert(MemberVO e) {
		mapper.insert(e);
	}

	@Override
	public void update(MemberVO e) {
		mapper.update(e);
	}

	@Override
	public void delete(MemberVO e) {
		mapper.delete(e);
	}
	
	public void memberDrop(Long idx) {
		mapper.memberDrop(idx);
	}

}