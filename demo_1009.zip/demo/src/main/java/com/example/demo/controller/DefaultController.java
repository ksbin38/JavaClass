package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.vo.MemberVO;

@Controller
public class DefaultController {

	// @RequestMapping("/"): GET, POST, DELETE, PUT, UPDATE
	@GetMapping("/")
	public ModelAndView index() {
		// ModelAndView: 데이터도 넣고 리턴해야될 html도 있을 때 사용
		ModelAndView mav = new ModelAndView();
		// setViewName: jsp파일을 리턴해주는 용도
		mav.setViewName("common/index"); // 원래는 index.jsp
		// jsp 파일에서 사용할 데이터 오브젝트
		mav.addObject("title", "인덱스 페이지"); // addObject(jsp 파일에 넘길때 데이터의 키 값, 키 값의 value)
		
		List<MemberVO> list = new ArrayList<>();
		
		MemberVO m1 = new MemberVO();
		m1.setIdx(1);
		m1.setIsAdmin(1);
		m1.setUserID("id1");
		m1.setPassword("123");
		m1.setUsername("이름");
		m1.setEmail("mail@mail.com");
		
		list.add(m1);
		
		MemberVO m2 = MemberVO.builder()
				.idx(2)
				.isAdmin(0)
				.userID("id2")
				.password("wd")
				.username("이름2")
				.email("email@mail.com")
				.build();
		
		list.add(m2);
		
		MemberVO m3 = MemberVO.builder()
				.idx(3)
				.isAdmin(0)
				.userID("id3")
				.password("wd333")
				.username("이름3")
				.email("alsdk@mail.com")
				.build();
		
		list.add(m3);
		
//		for (int i = 0; i < list.size(); i++) {
//			System.out.println(list.get(i).toString());
//		}
		// 위와 같음
//		for (MemberVO vo : list) {
//			System.out.println(vo.toString());
//		}
		
		mav.addObject("memberList", list);
		
		return mav;
	}
}
