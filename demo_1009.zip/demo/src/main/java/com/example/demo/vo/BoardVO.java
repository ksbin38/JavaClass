package com.example.demo.vo;

import java.time.LocalDateTime;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// lombok 설치 후 사용 가능
// 멤버변수의 getter 자동 생성
@Getter
// 멤버변수의 setter 자동 생성
@Setter
// 객체의 toString 메서드 자동 생성
@ToString
// 파라미터 없는 디폴트 컨스트럭터 생성
@NoArgsConstructor
public class BoardVO {
	private int idx;
	private int cate;
	private String title;
	private String content;
	private String regID;
	private LocalDateTime regTime;
	private String updID;
	private LocalDateTime updDate;
}
