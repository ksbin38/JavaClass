package com.example.demo.vo;

import java.time.LocalDateTime;

import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

// lombok 설치 후 사용 가능
// 멤버변수의 getter 자동 생성
@Getter
// 멤버변수의 setter 자동 생성
@Setter
// 객체의 toString 메서드 자동 생성
@ToString
// 파라미터 없는 디폴트 컨스트럭터 생성
@NoArgsConstructor
// 모든 멤버 변수를 파라미터로 하는 컨스트럭터 생성(가급적이면 사용하지 않는게 좋다)
// @AllArgsConstructor
public class MemberVO {
	private int idx;
	private int isAdmin;
	private String userID;
	private String password;
	private String username;
	private String email;
	private LocalDateTime regDate;
	private int isUse;
	private LocalDateTime dropDate;
	
	@Builder
	public MemberVO(int idx, int isAdmin, String userID, String password, String username, String email,
			LocalDateTime regDate, int isUse, LocalDateTime dropDate) {
		this.idx = idx;
		this.isAdmin = isAdmin;
		this.userID = userID;
		this.password = password;
		this.username = username;
		this.email = email;
		this.regDate = regDate;
		this.isUse = isUse;
		this.dropDate = dropDate;
	}
	
}
