package com.example.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class DefaultController {

	// @RequestMapping("/"): GET, POST, DELETE, PUT, UPDATE
	@GetMapping("/")
	public ModelAndView index() {
		// ModelAndView: 데이터도 넣고 리턴해야될 html도 있을 때 사용
		ModelAndView mav = new ModelAndView();
		// setViewName: jsp파일을 리턴해주는 용도
		mav.setViewName("index"); // 원래는 index.jsp
		// jsp 파일에서 사용할 데이터 오브젝트
		mav.addObject("title", "인덱스 페이지"); // addObject(jsp 파일에 넘길때 데이터의 키 값, 키 값의 value)
		return mav;
	}
}
