package com.example.demo.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.mapper.MemberMapper;
import com.example.demo.service.CrudService;
import com.example.demo.vo.MemberVO;

public class MemberServiceImpl implements CrudService<MemberVO> {

	@Autowired
	private MemberMapper mapper;
	
	@Override
	public List<MemberVO> selectList(MemberVO e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MemberVO selectOne(MemberVO e) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(MemberVO e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(MemberVO e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(MemberVO e) {
		// TODO Auto-generated method stub
		
	}

}
